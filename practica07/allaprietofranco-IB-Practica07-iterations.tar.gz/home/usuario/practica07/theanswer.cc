#include <iostream>

int main() {
  int valor;
  std::cout << "42" << std::endl;
}
