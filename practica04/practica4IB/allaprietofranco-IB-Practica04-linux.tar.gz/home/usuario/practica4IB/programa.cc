#include <iostream>

int main() {
int variable {2};

//variable = &;
variable = variable - 4;
variable++;
std::cout << variable;
}
