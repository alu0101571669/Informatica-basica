#include <iostream>

int main() {

int p {2}, v{3}, r;

std::cout << r = v << p = v << r = p;
return 0;
}
