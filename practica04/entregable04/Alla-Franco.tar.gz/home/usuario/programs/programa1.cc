#include <iostream>

using namespace std;

int main() {
    int variable{2};

    // Variable = 6;
    variable = variable -4;
    variable++;
    cout << variable;
}