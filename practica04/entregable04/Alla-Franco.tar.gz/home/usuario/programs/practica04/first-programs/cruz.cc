#include <iostream>
#include <string>
using namespace std;

int main() {
  string esquina_superior = "*   *";
  string esquina_inferior = " * *";
  string centro = "  *";
  cout << esquina_superior << endl;
  cout << esquina_inferior << endl;
  cout << centro << endl;
  cout << esquina_inferior << endl;
  cout << esquina_superior << endl;

  return 0;
}