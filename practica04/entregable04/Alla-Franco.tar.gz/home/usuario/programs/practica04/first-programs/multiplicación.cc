#include <iostream>

using namespace std;

int main() {
  double numero1, numero2;
  cout << "Número 1: ";
  cin >> numero1;
  cout << "Número 2: ";
  cin >> numero2;
  double multiplicacion = numero1 * numero2;
  cout << "La multiplicación de los numeros es: " << multiplicacion << endl;

  return 0;
}