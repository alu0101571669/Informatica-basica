#include <iostream>
using namespace std;

int main() {
  float ml, km;
  cout << "Milles? ";
  cin >> ml;
  km = ml * 1.609;  // 1 //
  cout << "Són " << km << " kilòmetres" << endl;
  
  return 0;
}