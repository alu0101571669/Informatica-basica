#include <iostream>

int main() {
  int operand1{12};
  int operand2{3};
  std::cout << operand1 % operand2;
  return 0;
}