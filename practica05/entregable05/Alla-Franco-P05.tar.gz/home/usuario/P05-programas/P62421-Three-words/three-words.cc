#include <iostream>

using namespace std;
/*Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología 
 * Grado en Ingeniería informática 2022-2023
 * Informática Básica 2022-2023

 * @file three-words.cc
 * @author Franco Alla Prieto alu0101571669@ull.edu.es
 * @date 16/10/2023
 * @brief Programa que te pide tres palabras y te las muestra en orden inver          so
*/

int main() {
  string palabra1, palabra2, palabra3;
  cin >> palabra1 >> palabra2 >> palabra3;
  cout << palabra3 << " " << palabra2 << " " << palabra1 << endl;
  return 0;
}
