#include <iostream>
using namespace std;

/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  *
  * @file sum-of-two-integer-numbers.cc
  * @author alu0101571669@ull.edu.es@ull.edu.es
  * @date 16/10/2023
  * @brief Programa que suma dos números
  */

int main() {
  int numero1, numero2, suma;
  cin >> numero1 >> numero2;
  suma = numero1 + numero2;
  cout << suma << endl;
  return 0;
}
