#include <iostream>

int main() {
double xy;  //coordenada x e y
std::cin >> xy;
if( xy > 1.1)
{
std::cout << "Fuera" << std::endl;
}
else
{
std::cout << "Dentro" << std::endl;
}
return 0;
}
