#include <iostream>

/*
Universidad de la laguna
autor: Franco Alla Prieto
Fecha: 29/10/2022
Finalidad: Programa que te dice cuantas horas encierra un número determinado de segundos
*/
int main() {
int segundos;

std::cin >> segundos;
std::cout << segundos / 3600 << std::endl;
return 0;
}
