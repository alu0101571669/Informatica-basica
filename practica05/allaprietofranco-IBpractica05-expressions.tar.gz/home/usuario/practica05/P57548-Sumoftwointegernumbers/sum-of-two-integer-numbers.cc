#include <iostream>
/*Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @file sum-of-two-integer-numbers.cc
  * @author Franco Alla Prieto alu0101571669@ull.edu.es
  * @date Oct 31 2022
  * @brief El programa coge dos números cualesquiera y los suma
  * 
*/

int main() {

int numero1, numero2;
std::cin >> numero1 >> numero2;
std::cout << numero1 + numero2 << std::endl;
return 0;
}
