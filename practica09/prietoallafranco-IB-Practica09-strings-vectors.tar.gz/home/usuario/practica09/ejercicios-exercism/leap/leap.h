#if !defined(LEAP_H)
#define LEAP_H
namespace leap {
    bool is_leap_year(int anyo);
}  // namespace leap
#endif // LEAP_H
